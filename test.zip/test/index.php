<html>
		<head>
			<title>Details</title>
            <style>
                body{
                    background-color: rgb(221, 139, 139);
                }
                .container{
                    background-color: rgb(231, 222, 222);
                    box-shadow: 1px 1px 2px 1px gray;
                    padding: 50px 8px 20px 30px;
                    width: 40%;
                    height: 82%;
                    margin-left: 29%;
                }
                .box{
                    width: 65%;
                    height: 2%;
                    border: 1px solid brown;
                    border-radius: 5px;
                    padding: 20px 15px 20px 15px;
                    margin: 10px 0px 15px 0px;
                }
                select{
                    width:75%;
                    border: 1px solid brown;
                    border-radius: 5px;
                    box-sizing: 1px 1px 2px 1px gray;
                    padding: 10px 15px 10px 15px;
                }
                .button{
                    width: 20%;
                    height: 1%;
                    border: 1px solid brown;
                    border-radius: 5px;
                    padding: 15px 15px 15px 15px;
                    margin: 2px 2px 2px 2px;
                    cursor: pointer;
                    
                }
            </style>
		</head>
		<body>
			<center><h1>Student Info</h1> </center>
            <div class="container">
			<form action="connect.php" method="POST">
				

				<label>Name</label> <br>
				<input type="text" class="box" name="name" required><br>

				<label>Contact Number</label> <br>
				<input type="number" class="box" name="number" required><br>

				<label>City</label> <br>
				<input type="text" class="box" name="city" required><br>

				<label >DropDownList Gender:</label><br>
				<select name="gender" required>
					<option value="">-Select-</option>
					<option value="m">Male</option>
					<option value="f">Female</option>
                    
				</select><br> 

				<label >DropDownList DOB:</label>  <br>
				<select name="bod" required>
					<option value="">-Select-</option>
					<option value="before">Before 2000</option>
					<option value="after">After 2000</option>
                </select><br> <br>
                    <input type="submit" class="button" name="save" value="Submit">
				
			</form>
		</div>
    </body>
</html>
	