<html>
    <head>
        <title> Data</title>
        <center><h1>Student Data</h1> </center>
        <style>
            body{
                    background-color:		#D0D0D0;
                }
           .th{
                background-color: white;
                box-shadow: 1px 1px 2px 1px gray;  
                margin-left: 29%;
                border-radius: 6px;
                      
            }
            
        </style>
    </head>
    <body>
        <table  class="th" border="2"  style=width:40%;>
        
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Number</th>
            <th>City</th>
            <th>Gender</th>
            <th>Date of Birth</th>
        </tr>
        
        <?php
        include("connect.php");
        error_reporting(0);
        $query ="select * from student_details";
        $data = mysqli_query($conn,$query);
        $total =mysqli_num_rows($data);
        
        if($total!=0){
            
            while($result= mysqli_fetch_assoc($data))
            {
                echo "
                <tr>
                <th>" .$result['id']."</th>
                <th>" .$result['name']."</th>
                <th>" .$result['number']."</th>
                <th>" .$result['city']."</th>
                <th>" .$result['gender']."</th>
                <th>" .$result['bod']."</th>
                </tr>";
            }
        }else{
            echo "No Records Found !";
        }
        ?>
    </table>
    </body>
</html>