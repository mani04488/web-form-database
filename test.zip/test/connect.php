<?php
$servername="localhost";
$username= "root";
$password="";
$database_name="rido";

$conn=mysqli_connect($servername,$username,$password,$database_name);

if(!$conn){
    die("Connection Failed: " . mysqli_connect_error());
}
if(isset($_POST['save'])){
    $name = $_POST['name'];
    $number = $_POST['number'];
    $city = $_POST['city'];
    $gender = $_POST['gender'];
    $bod = $_POST['bod'];

    
    $sql_query = "INSERT INTO student_details (name, number, city, gender, bod )
    VALUES ('$name', '$number',' $city', '$gender', '$bod')";
    if(mysqli_query($conn, $sql_query))
    {
        
        echo "Details inserted Successfully !";

    }
    else{
        echo "Error: " . $sql . "" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>